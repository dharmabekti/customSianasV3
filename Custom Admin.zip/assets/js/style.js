// Ambil semua menu
const menuItems = document.querySelectorAll('.mobile-bottom-nav a');

// Dapatkan path URL saat ini
const currentPath = window.location.pathname.split('/').pop();

// Loop dan beri class 'active' pada menu yang sesuai
menuItems.forEach(item => {
  const hrefPath = item.getAttribute('href');
if (hrefPath === currentPath) {
    item.classList.add('active'); // bisa dikombinasikan dengan CSS
  }
});

document.addEventListener('DOMContentLoaded', function () {
  const profileContent = document.querySelectorAll('#profileContent .content-section');
  const mobileContainer = document.getElementById('mobileProfile');

  profileContent.forEach(section => {
    const card = document.createElement('div');
    card.className = 'card shadow-sm mb-3';
    const body = document.createElement('div');
    body.className = 'card-body';
    body.innerHTML = section.innerHTML; // ambil isi dari tab
    card.appendChild(body);
    mobileContainer.appendChild(card);
  });
});